/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.lepuserprofile.service.persistence;

import com.lepuserprofile.model.UserProfile;

import com.liferay.portal.service.persistence.BasePersistence;

/**
 * The persistence interface for the user profile service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see UserProfilePersistenceImpl
 * @see UserProfileUtil
 * @generated
 */
public interface UserProfilePersistence extends BasePersistence<UserProfile> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link UserProfileUtil} to access the user profile persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the user profiles where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user profiles where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user profiles where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profiles before and after the current user profile in the ordered set where uuid = &#63;.
	*
	* @param userProfileId the primary key of the current user profile
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile[] findByUuid_PrevAndNext(
		long userProfileId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the user profiles where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user profiles where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile where uuid = &#63; and groupId = &#63; or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the user profile where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the user profile that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user profiles where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the user profiles where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user profiles where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user profiles where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profiles before and after the current user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param userProfileId the primary key of the current user profile
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile[] findByUuid_C_PrevAndNext(
		long userProfileId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the user profiles where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user profiles where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @return the matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByuserProfile(
		long userId, int userProfileStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByuserProfile(
		long userId, int userProfileStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findByuserProfile(
		long userId, int userProfileStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByuserProfile_First(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByuserProfile_First(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByuserProfile_Last(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByuserProfile_Last(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profiles before and after the current user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userProfileId the primary key of the current user profile
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile[] findByuserProfile_PrevAndNext(
		long userProfileId, long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the user profiles where userId = &#63; and userProfileStatus = &#63; from the database.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @throws SystemException if a system exception occurred
	*/
	public void removeByuserProfile(long userId, int userProfileStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserProfile(long userId, int userProfileStatus)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile where userId = &#63; or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	*
	* @param userId the user ID
	* @return the matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByuserProfileId(long userId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile where userId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param userId the user ID
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByuserProfileId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile where userId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param userId the user ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByuserProfileId(
		long userId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the user profile where userId = &#63; from the database.
	*
	* @param userId the user ID
	* @return the user profile that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile removeByuserProfileId(
		long userId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user profiles where userId = &#63;.
	*
	* @param userId the user ID
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserProfileId(long userId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the user profile in the entity cache if it is enabled.
	*
	* @param userProfile the user profile
	*/
	public void cacheResult(com.lepuserprofile.model.UserProfile userProfile);

	/**
	* Caches the user profiles in the entity cache if it is enabled.
	*
	* @param userProfiles the user profiles
	*/
	public void cacheResult(
		java.util.List<com.lepuserprofile.model.UserProfile> userProfiles);

	/**
	* Creates a new user profile with the primary key. Does not add the user profile to the database.
	*
	* @param userProfileId the primary key for the new user profile
	* @return the new user profile
	*/
	public com.lepuserprofile.model.UserProfile create(long userProfileId);

	/**
	* Removes the user profile with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userProfileId the primary key of the user profile
	* @return the user profile that was removed
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile remove(long userProfileId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	public com.lepuserprofile.model.UserProfile updateImpl(
		com.lepuserprofile.model.UserProfile userProfile)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile with the primary key or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	*
	* @param userProfileId the primary key of the user profile
	* @return the user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile findByPrimaryKey(
		long userProfileId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user profile with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param userProfileId the primary key of the user profile
	* @return the user profile, or <code>null</code> if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.lepuserprofile.model.UserProfile fetchByPrimaryKey(
		long userProfileId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the user profiles.
	*
	* @return the user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user profiles.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user profiles.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user profiles
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.lepuserprofile.model.UserProfile> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the user profiles from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user profiles.
	*
	* @return the number of user profiles
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}