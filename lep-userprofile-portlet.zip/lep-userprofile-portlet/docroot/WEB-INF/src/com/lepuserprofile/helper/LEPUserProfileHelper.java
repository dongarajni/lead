package com.lepuserprofile.helper;

import com.lepuserprofile.NoSuchUserProfileException;
import com.lepuserprofile.model.UserProfile;
import com.lepuserprofile.model.UserProfileModel;
import com.lepuserprofile.model.impl.UserProfileImpl;
import com.lepuserprofile.service.UserProfileLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.NoSuchWorkflowDefinitionLinkException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.workflow.WorkflowHandlerRegistryUtil;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Country;
import com.liferay.portal.model.User;
import com.liferay.portal.model.UserConstants;
import com.liferay.portal.model.WorkflowDefinitionLink;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.service.WorkflowDefinitionLinkLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;


public class LEPUserProfileHelper {
	private static final Log LOGGER = LogFactoryUtil.getLog(LEPUserProfileHelper.class);
	
	public static void userProfileRender(RenderRequest renderReq, RenderResponse renderRes){
	
		ThemeDisplay themeDisplay = (ThemeDisplay) renderReq
				.getAttribute(WebKeys.THEME_DISPLAY);
		
		String cmd= ParamUtil.getString(renderReq, "editProfile");
		
		HttpServletRequest httpReq = PortalUtil.getOriginalServletRequest(PortalUtil.getHttpServletRequest(renderReq)); 
		String uId = httpReq.getParameter("userId");
		
		String strUserId = ParamUtil.getString(renderReq, "userId");
		
		if(Validator.isNull(uId)){
			try{
			uId= strUserId;
			} catch(NumberFormatException e){ uId="0";}
		}
		
		User user = null;
		if(Validator.isNotNull(uId)){
		try {
			user = UserLocalServiceUtil.getUser(Long.parseLong(uId));
	        List<Address> addresses = user.getAddresses();
			for (Address address : addresses) {
				String city = address.getCity();
				Country country = address.getCountry();
				renderReq.setAttribute("city", city);
				renderReq.setAttribute("country", country.getName());
			}
			
			renderReq.setAttribute("ImagePath", UserConstants.getPortraitURL(themeDisplay.getPathImage(), user.isMale(), user.getPortraitId()));
			renderReq.setAttribute("lepUser", user);
			
		} catch (PortalException e) {
			e.printStackTrace();
		} catch (SystemException e) {
			e.printStackTrace();
		}
		}

		List<UserProfile> userProfiles = null;
		UserProfile userProfile = null;
		try {
		//userProfile = UserProfileLocalServiceUtil.findByUserProfileId(user.getUserId());
		userProfiles = UserProfileLocalServiceUtil.findByuserProfileId(user.getUserId(),WorkflowConstants.STATUS_APPROVED);
		
		if(userProfiles.size() != 0){
			userProfile = userProfiles.get(0);
//			LOGGER.info("userProfileId==="+userProfile.getUserProfileId());
			for (UserProfile Profiles : userProfiles) {
				if(Profiles.getUserProfileId() != userProfile.getUserProfileId()){
					try {
						UserProfileLocalServiceUtil.deleteUserProfile(Profiles.getUserProfileId());
					} catch (PortalException e) {
						e.printStackTrace();
					}
					
				}
				
			}
			int userProfileStatus = userProfile.getUserProfileStatus();
//			LOGGER.info("userProfileStatus===="+userProfileStatus);
			
			if(userProfileStatus == WorkflowConstants.STATUS_APPROVED){
						
				String bioData = userProfile.getBioData();
				renderReq.setAttribute("bioData", bioData);
				
				String site = userProfile.getSite();
				renderReq.setAttribute("site", site);
				
				long userProfileId = userProfile.getUserProfileId();
				renderReq.setAttribute("userProfileId", userProfileId);
			}
		}
		
		} catch (SystemException e1) {
			e1.printStackTrace();
		}
		
		if(cmd.equals("editProfile")){
			
			String editPortraitUrl = themeDisplay.getPortalURL()+"/group/control_panel/manage?p_p_id=2&p_p_state=pop_up&p_p_mode=view&_2_portrait_id=0&_2_p_u_i_d="+user.getUserId()+"&_2_struts_action=%2Fmy_account%2Fedit_user_portrait";
			renderReq.setAttribute("editPortraitUrl", editPortraitUrl);
			
			try {
				String portraitURL = user.getPortraitURL(themeDisplay);
				renderReq.setAttribute("portraitURL", portraitURL);
				
				long portraitId = user.getPortraitId();
				renderReq.setAttribute("portraitId", portraitId);
				
				String defaultURL = themeDisplay.getPortalURL()+UserConstants.getPortraitURL(themeDisplay.getPathImage(), user.isMale(), 0);
				renderReq.setAttribute("defaultURL", defaultURL);
				
			} catch (PortalException e) {
				e.printStackTrace();
			} catch (SystemException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	public static void addEditUserProfile(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException, PortalException, SystemException{
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest
				.getAttribute(WebKeys.THEME_DISPLAY);
		
		String firstName = ParamUtil.getString(actionRequest, "firstName");
		String lastName = ParamUtil.getString(actionRequest, "lastName");
		String jobTitle = ParamUtil.getString(actionRequest, "jobTitle");
		String site = ParamUtil.getString(actionRequest, "site");
		String bioData = ParamUtil.getString(actionRequest, "bioData");
		long userId = ParamUtil.getLong(actionRequest, "userId");
		long userProfileId = ParamUtil.getLong(actionRequest, "userProfileId");
		
		try {
			User user = UserLocalServiceUtil.getUser(userId);
			user.setFirstName(firstName);
			user.setLastName(lastName);
			user.setJobTitle(jobTitle);
			
			user = UserLocalServiceUtil.updateUser(user);
			
		} catch (PortalException e) {
			e.printStackTrace();
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		if(Validator.isNotNull(userProfileId)){
			
			UserProfile userprofile = UserProfileLocalServiceUtil.getUserProfile(userProfileId);
			
			updateUserProfile(firstName, lastName, jobTitle, site, bioData, userId, userProfileId,actionRequest,userprofile.getResourcePrimKey(),userprofile.getCreateDate());
			SessionMessages.add(actionRequest, "profile-updated");
		}else{
			addUserprofile(firstName, lastName, jobTitle, site, bioData, userId,actionRequest);
			SessionMessages.add(actionRequest, "profile-updated");
		}
		
		actionResponse.sendRedirect(themeDisplay.getPortalURL()+"/group/leadership/user-profile"+"?userId="+userId);
		
	}
	
		
	private static UserProfile addUserprofile(String firstName, String lastName, String jobTitle, String site, String bioData, long userId, PortletRequest actionRequest){
		
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		UserProfile userProfile = null;
		try {
			userProfile = UserProfileLocalServiceUtil.createUserProfile(CounterLocalServiceUtil.increment(UserProfile.class.getName()));
			long resourcePrimkey = CounterLocalServiceUtil.increment();
			
			userProfile.setResourcePrimKey(resourcePrimkey);
			userProfile.setFirstName(firstName);
			userProfile.setLastName(lastName);
			userProfile.setJobTitle(jobTitle);
			userProfile.setSite(site);
			userProfile.setBioData(bioData);
			userProfile.setUserId(userId);
			userProfile.setGroupId(themeDisplay.getScopeGroupId());
			userProfile.setCompanyId(themeDisplay.getCompanyId());
			userProfile.setCreateDate(new Date());
			userProfile.setModifiedDate(new Date());
			userProfile.setUserProfileStatus(WorkflowConstants.STATUS_DRAFT);
			
			
			userProfile = UserProfileLocalServiceUtil.addUserProfile(userProfile);
			
			try {
				userProfileWorkflow(actionRequest, userProfile);
			} catch (PortalException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userProfile;
		
	}

	private static UserProfile updateUserProfile(String firstName, String lastName, String jobTitle, String site, String bioData, long userId, long userProfileId, PortletRequest actionRequest, long resourcePrimKey, Date createDate){
		
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		//UserProfile userProfile = new UserProfileImpl();
		UserProfile userProfile = null; 
		try {
			userProfile = UserProfileLocalServiceUtil.createUserProfile(CounterLocalServiceUtil.increment(UserProfile.class.getName()));
		
			userProfile.setResourcePrimKey(resourcePrimKey);
			userProfile.setFirstName(firstName);
			userProfile.setLastName(lastName);
			userProfile.setJobTitle(jobTitle);
			userProfile.setSite(site);
			userProfile.setBioData(bioData);
			userProfile.setUserId(userId);
			userProfile.setGroupId(themeDisplay.getScopeGroupId());
			userProfile.setCompanyId(themeDisplay.getCompanyId());
			userProfile.setCreateDate(createDate);
			userProfile.setModifiedDate(new Date());
			userProfile.setUserProfileStatus(WorkflowConstants.STATUS_DRAFT);
			
		
			userProfile = UserProfileLocalServiceUtil.updateUserProfile(userProfile);
			try {
				userProfileWorkflow(actionRequest, userProfile);
			} catch (PortalException e) {
				e.printStackTrace();
			}
			
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		return userProfile;
		
	}

	private static UserProfile userProfileWorkflow(PortletRequest actionRequest, UserProfile userProfile) throws PortalException, SystemException{
		
		ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		ServiceContext serviceContext = ServiceContextFactory.getInstance(UserProfile.class.getName(), actionRequest);
		
		WorkflowDefinitionLink workflowDefinitionLink=null;
		try {
			workflowDefinitionLink = WorkflowDefinitionLinkLocalServiceUtil.getDefaultWorkflowDefinitionLink(userProfile.getCompanyId(), UserProfile.class.getName(), 0, 0);
		} catch (PortalException e) {
			if(e instanceof NoSuchWorkflowDefinitionLinkException){
				SessionMessages.add(actionRequest.getPortletSession(),"workflow-not-enabled");
			}
			e.printStackTrace();
		}
		
		if(userProfile != null && workflowDefinitionLink!=null){
				LOGGER.info("============= Workflow Update Entry ==========");
				AssetEntryLocalServiceUtil.updateEntry(themeDisplay.getUserId(), userProfile.getGroupId(),
						UserProfile.class.getName(), userProfile.getUserProfileId(),
						serviceContext.getAssetCategoryIds(),
						serviceContext.getAssetTagNames());
				WorkflowHandlerRegistryUtil.startWorkflowInstance(
						userProfile.getCompanyId(), userProfile.getGroupId(), themeDisplay.getUserId(),
						UserProfile.class.getName(), userProfile.getPrimaryKey(), userProfile,
						serviceContext);
			
		}
		
		return userProfile;
		
	}
	
	
	
}
