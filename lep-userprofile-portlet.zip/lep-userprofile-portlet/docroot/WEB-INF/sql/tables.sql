create table lep_UserProfile (
	uuid_ VARCHAR(75) null,
	userProfileId LONG not null primary key,
	resourcePrimKey LONG,
	firstName VARCHAR(75) null,
	lastName VARCHAR(75) null,
	jobTitle VARCHAR(75) null,
	site VARCHAR(75) null,
	bioData VARCHAR(75) null,
	userProfileStatus INTEGER,
	statusByUserId LONG,
	statusDate DATE null,
	groupId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	companyId LONG,
	createDate DATE null,
	modifiedDate DATE null
);