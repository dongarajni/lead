package com.lepuserprofile.handler;

import com.lepuserprofile.model.UserProfile;
import com.lepuserprofile.service.UserProfileLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portlet.asset.model.AssetRenderer;
import com.liferay.portlet.asset.model.BaseAssetRendererFactory;

public class UserProfileAssetRendererFactory extends BaseAssetRendererFactory{

	public static final String TYPE = "UserProfile";
    public static final String CLASS_NAME = UserProfile.class.getName();
	
	@Override
	public AssetRenderer getAssetRenderer(long classPK, int type)
			throws PortalException, SystemException {

		UserProfile userProfile = UserProfileLocalServiceUtil.getUserProfile(classPK);
		
		return new UserProfileAssetRenderer(userProfile);
	}

	@Override
	public String getClassName() {
		// TODO Auto-generated method stub
		return CLASS_NAME;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return TYPE;
	}

}
