/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.lepuserprofile.service.persistence;

import com.lepuserprofile.NoSuchUserProfileException;

import com.lepuserprofile.model.UserProfile;
import com.lepuserprofile.model.impl.UserProfileImpl;
import com.lepuserprofile.model.impl.UserProfileModelImpl;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the user profile service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see UserProfilePersistence
 * @see UserProfileUtil
 * @generated
 */
public class UserProfilePersistenceImpl extends BasePersistenceImpl<UserProfile>
	implements UserProfilePersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link UserProfileUtil} to access the user profile persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = UserProfileImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			UserProfileModelImpl.UUID_COLUMN_BITMASK |
			UserProfileModelImpl.STATUSDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the user profiles where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByUuid(String uuid) throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the user profiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @return the range of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the user profiles where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<UserProfile> list = (List<UserProfile>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (UserProfile userProfile : list) {
				if (!Validator.equals(uuid, userProfile.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_USERPROFILE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(UserProfileModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<UserProfile>(list);
				}
				else {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first user profile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByUuid_First(uuid, orderByComparator);

		if (userProfile != null) {
			return userProfile;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchUserProfileException(msg.toString());
	}

	/**
	 * Returns the first user profile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<UserProfile> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last user profile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByUuid_Last(uuid, orderByComparator);

		if (userProfile != null) {
			return userProfile;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchUserProfileException(msg.toString());
	}

	/**
	 * Returns the last user profile in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<UserProfile> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the user profiles before and after the current user profile in the ordered set where uuid = &#63;.
	 *
	 * @param userProfileId the primary key of the current user profile
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile[] findByUuid_PrevAndNext(long userProfileId,
		String uuid, OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = findByPrimaryKey(userProfileId);

		Session session = null;

		try {
			session = openSession();

			UserProfile[] array = new UserProfileImpl[3];

			array[0] = getByUuid_PrevAndNext(session, userProfile, uuid,
					orderByComparator, true);

			array[1] = userProfile;

			array[2] = getByUuid_PrevAndNext(session, userProfile, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected UserProfile getByUuid_PrevAndNext(Session session,
		UserProfile userProfile, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_USERPROFILE_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(UserProfileModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(userProfile);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<UserProfile> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the user profiles where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (UserProfile userProfile : findByUuid(uuid, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(userProfile);
		}
	}

	/**
	 * Returns the number of user profiles where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_USERPROFILE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "userProfile.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "userProfile.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(userProfile.uuid IS NULL OR userProfile.uuid = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_UUID_G = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() },
			UserProfileModelImpl.UUID_COLUMN_BITMASK |
			UserProfileModelImpl.GROUPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_G = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns the user profile where uuid = &#63; and groupId = &#63; or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByUUID_G(String uuid, long groupId)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByUUID_G(uuid, groupId);

		if (userProfile == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("uuid=");
			msg.append(uuid);

			msg.append(", groupId=");
			msg.append(groupId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchUserProfileException(msg.toString());
		}

		return userProfile;
	}

	/**
	 * Returns the user profile where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByUUID_G(String uuid, long groupId)
		throws SystemException {
		return fetchByUUID_G(uuid, groupId, true);
	}

	/**
	 * Returns the user profile where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByUUID_G(String uuid, long groupId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { uuid, groupId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs, this);
		}

		if (result instanceof UserProfile) {
			UserProfile userProfile = (UserProfile)result;

			if (!Validator.equals(uuid, userProfile.getUuid()) ||
					(groupId != userProfile.getGroupId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_USERPROFILE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				List<UserProfile> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
						finderArgs, list);
				}
				else {
					UserProfile userProfile = list.get(0);

					result = userProfile;

					cacheResult(userProfile);

					if ((userProfile.getUuid() == null) ||
							!userProfile.getUuid().equals(uuid) ||
							(userProfile.getGroupId() != groupId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
							finderArgs, userProfile);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (UserProfile)result;
		}
	}

	/**
	 * Removes the user profile where uuid = &#63; and groupId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the user profile that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile removeByUUID_G(String uuid, long groupId)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = findByUUID_G(uuid, groupId);

		return remove(userProfile);
	}

	/**
	 * Returns the number of user profiles where uuid = &#63; and groupId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the number of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUUID_G(String uuid, long groupId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_G;

		Object[] finderArgs = new Object[] { uuid, groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_USERPROFILE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_G_UUID_1 = "userProfile.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_2 = "userProfile.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_3 = "(userProfile.uuid IS NULL OR userProfile.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_G_GROUPID_2 = "userProfile.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C =
		new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() },
			UserProfileModelImpl.UUID_COLUMN_BITMASK |
			UserProfileModelImpl.COMPANYID_COLUMN_BITMASK |
			UserProfileModelImpl.STATUSDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_C = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns all the user profiles where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByUuid_C(String uuid, long companyId)
		throws SystemException {
		return findByUuid_C(uuid, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the user profiles where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @return the range of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByUuid_C(String uuid, long companyId,
		int start, int end) throws SystemException {
		return findByUuid_C(uuid, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the user profiles where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] { uuid, companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] {
					uuid, companyId,
					
					start, end, orderByComparator
				};
		}

		List<UserProfile> list = (List<UserProfile>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (UserProfile userProfile : list) {
				if (!Validator.equals(uuid, userProfile.getUuid()) ||
						(companyId != userProfile.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_USERPROFILE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(UserProfileModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<UserProfile>(list);
				}
				else {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByUuid_C_First(uuid, companyId,
				orderByComparator);

		if (userProfile != null) {
			return userProfile;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchUserProfileException(msg.toString());
	}

	/**
	 * Returns the first user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<UserProfile> list = findByUuid_C(uuid, companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByUuid_C_Last(uuid, companyId,
				orderByComparator);

		if (userProfile != null) {
			return userProfile;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchUserProfileException(msg.toString());
	}

	/**
	 * Returns the last user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid_C(uuid, companyId);

		if (count == 0) {
			return null;
		}

		List<UserProfile> list = findByUuid_C(uuid, companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the user profiles before and after the current user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param userProfileId the primary key of the current user profile
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile[] findByUuid_C_PrevAndNext(long userProfileId,
		String uuid, long companyId, OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = findByPrimaryKey(userProfileId);

		Session session = null;

		try {
			session = openSession();

			UserProfile[] array = new UserProfileImpl[3];

			array[0] = getByUuid_C_PrevAndNext(session, userProfile, uuid,
					companyId, orderByComparator, true);

			array[1] = userProfile;

			array[2] = getByUuid_C_PrevAndNext(session, userProfile, uuid,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected UserProfile getByUuid_C_PrevAndNext(Session session,
		UserProfile userProfile, String uuid, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_USERPROFILE_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_C_UUID_2);
		}

		query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(UserProfileModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(userProfile);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<UserProfile> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the user profiles where uuid = &#63; and companyId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid_C(String uuid, long companyId)
		throws SystemException {
		for (UserProfile userProfile : findByUuid_C(uuid, companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(userProfile);
		}
	}

	/**
	 * Returns the number of user profiles where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the number of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid_C(String uuid, long companyId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_C;

		Object[] finderArgs = new Object[] { uuid, companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_USERPROFILE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_C_UUID_1 = "userProfile.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_2 = "userProfile.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_3 = "(userProfile.uuid IS NULL OR userProfile.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_C_COMPANYID_2 = "userProfile.companyId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_USERPROFILE =
		new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByuserProfile",
			new String[] {
				Long.class.getName(), Integer.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERPROFILE =
		new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByuserProfile",
			new String[] { Long.class.getName(), Integer.class.getName() },
			UserProfileModelImpl.USERID_COLUMN_BITMASK |
			UserProfileModelImpl.USERPROFILESTATUS_COLUMN_BITMASK |
			UserProfileModelImpl.STATUSDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_USERPROFILE = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByuserProfile",
			new String[] { Long.class.getName(), Integer.class.getName() });

	/**
	 * Returns all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @return the matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByuserProfile(long userId,
		int userProfileStatus) throws SystemException {
		return findByuserProfile(userId, userProfileStatus, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @return the range of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByuserProfile(long userId,
		int userProfileStatus, int start, int end) throws SystemException {
		return findByuserProfile(userId, userProfileStatus, start, end, null);
	}

	/**
	 * Returns an ordered range of all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findByuserProfile(long userId,
		int userProfileStatus, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERPROFILE;
			finderArgs = new Object[] { userId, userProfileStatus };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_USERPROFILE;
			finderArgs = new Object[] {
					userId, userProfileStatus,
					
					start, end, orderByComparator
				};
		}

		List<UserProfile> list = (List<UserProfile>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (UserProfile userProfile : list) {
				if ((userId != userProfile.getUserId()) ||
						(userProfileStatus != userProfile.getUserProfileStatus())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_USERPROFILE_WHERE);

			query.append(_FINDER_COLUMN_USERPROFILE_USERID_2);

			query.append(_FINDER_COLUMN_USERPROFILE_USERPROFILESTATUS_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(UserProfileModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				qPos.add(userProfileStatus);

				if (!pagination) {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<UserProfile>(list);
				}
				else {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByuserProfile_First(long userId,
		int userProfileStatus, OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByuserProfile_First(userId,
				userProfileStatus, orderByComparator);

		if (userProfile != null) {
			return userProfile;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("userId=");
		msg.append(userId);

		msg.append(", userProfileStatus=");
		msg.append(userProfileStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchUserProfileException(msg.toString());
	}

	/**
	 * Returns the first user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByuserProfile_First(long userId,
		int userProfileStatus, OrderByComparator orderByComparator)
		throws SystemException {
		List<UserProfile> list = findByuserProfile(userId, userProfileStatus,
				0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByuserProfile_Last(long userId,
		int userProfileStatus, OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByuserProfile_Last(userId,
				userProfileStatus, orderByComparator);

		if (userProfile != null) {
			return userProfile;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("userId=");
		msg.append(userId);

		msg.append(", userProfileStatus=");
		msg.append(userProfileStatus);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchUserProfileException(msg.toString());
	}

	/**
	 * Returns the last user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByuserProfile_Last(long userId,
		int userProfileStatus, OrderByComparator orderByComparator)
		throws SystemException {
		int count = countByuserProfile(userId, userProfileStatus);

		if (count == 0) {
			return null;
		}

		List<UserProfile> list = findByuserProfile(userId, userProfileStatus,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the user profiles before and after the current user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userProfileId the primary key of the current user profile
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile[] findByuserProfile_PrevAndNext(long userProfileId,
		long userId, int userProfileStatus, OrderByComparator orderByComparator)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = findByPrimaryKey(userProfileId);

		Session session = null;

		try {
			session = openSession();

			UserProfile[] array = new UserProfileImpl[3];

			array[0] = getByuserProfile_PrevAndNext(session, userProfile,
					userId, userProfileStatus, orderByComparator, true);

			array[1] = userProfile;

			array[2] = getByuserProfile_PrevAndNext(session, userProfile,
					userId, userProfileStatus, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected UserProfile getByuserProfile_PrevAndNext(Session session,
		UserProfile userProfile, long userId, int userProfileStatus,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_USERPROFILE_WHERE);

		query.append(_FINDER_COLUMN_USERPROFILE_USERID_2);

		query.append(_FINDER_COLUMN_USERPROFILE_USERPROFILESTATUS_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(UserProfileModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(userId);

		qPos.add(userProfileStatus);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(userProfile);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<UserProfile> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the user profiles where userId = &#63; and userProfileStatus = &#63; from the database.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByuserProfile(long userId, int userProfileStatus)
		throws SystemException {
		for (UserProfile userProfile : findByuserProfile(userId,
				userProfileStatus, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(userProfile);
		}
	}

	/**
	 * Returns the number of user profiles where userId = &#63; and userProfileStatus = &#63;.
	 *
	 * @param userId the user ID
	 * @param userProfileStatus the user profile status
	 * @return the number of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByuserProfile(long userId, int userProfileStatus)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_USERPROFILE;

		Object[] finderArgs = new Object[] { userId, userProfileStatus };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_USERPROFILE_WHERE);

			query.append(_FINDER_COLUMN_USERPROFILE_USERID_2);

			query.append(_FINDER_COLUMN_USERPROFILE_USERPROFILESTATUS_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				qPos.add(userProfileStatus);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_USERPROFILE_USERID_2 = "userProfile.userId = ? AND ";
	private static final String _FINDER_COLUMN_USERPROFILE_USERPROFILESTATUS_2 = "userProfile.userProfileStatus = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_USERPROFILEID = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, UserProfileImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByuserProfileId",
			new String[] { Long.class.getName() },
			UserProfileModelImpl.USERID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_USERPROFILEID = new FinderPath(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByuserProfileId",
			new String[] { Long.class.getName() });

	/**
	 * Returns the user profile where userId = &#63; or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	 *
	 * @param userId the user ID
	 * @return the matching user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByuserProfileId(long userId)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByuserProfileId(userId);

		if (userProfile == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("userId=");
			msg.append(userId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchUserProfileException(msg.toString());
		}

		return userProfile;
	}

	/**
	 * Returns the user profile where userId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param userId the user ID
	 * @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByuserProfileId(long userId)
		throws SystemException {
		return fetchByuserProfileId(userId, true);
	}

	/**
	 * Returns the user profile where userId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param userId the user ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByuserProfileId(long userId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { userId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
					finderArgs, this);
		}

		if (result instanceof UserProfile) {
			UserProfile userProfile = (UserProfile)result;

			if ((userId != userProfile.getUserId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_USERPROFILE_WHERE);

			query.append(_FINDER_COLUMN_USERPROFILEID_USERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				List<UserProfile> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"UserProfilePersistenceImpl.fetchByuserProfileId(long, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					UserProfile userProfile = list.get(0);

					result = userProfile;

					cacheResult(userProfile);

					if ((userProfile.getUserId() != userId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
							finderArgs, userProfile);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (UserProfile)result;
		}
	}

	/**
	 * Removes the user profile where userId = &#63; from the database.
	 *
	 * @param userId the user ID
	 * @return the user profile that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile removeByuserProfileId(long userId)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = findByuserProfileId(userId);

		return remove(userProfile);
	}

	/**
	 * Returns the number of user profiles where userId = &#63;.
	 *
	 * @param userId the user ID
	 * @return the number of matching user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByuserProfileId(long userId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_USERPROFILEID;

		Object[] finderArgs = new Object[] { userId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_USERPROFILE_WHERE);

			query.append(_FINDER_COLUMN_USERPROFILEID_USERID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(userId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_USERPROFILEID_USERID_2 = "userProfile.userId = ?";

	public UserProfilePersistenceImpl() {
		setModelClass(UserProfile.class);
	}

	/**
	 * Caches the user profile in the entity cache if it is enabled.
	 *
	 * @param userProfile the user profile
	 */
	@Override
	public void cacheResult(UserProfile userProfile) {
		EntityCacheUtil.putResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileImpl.class, userProfile.getPrimaryKey(), userProfile);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
			new Object[] { userProfile.getUuid(), userProfile.getGroupId() },
			userProfile);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
			new Object[] { userProfile.getUserId() }, userProfile);

		userProfile.resetOriginalValues();
	}

	/**
	 * Caches the user profiles in the entity cache if it is enabled.
	 *
	 * @param userProfiles the user profiles
	 */
	@Override
	public void cacheResult(List<UserProfile> userProfiles) {
		for (UserProfile userProfile : userProfiles) {
			if (EntityCacheUtil.getResult(
						UserProfileModelImpl.ENTITY_CACHE_ENABLED,
						UserProfileImpl.class, userProfile.getPrimaryKey()) == null) {
				cacheResult(userProfile);
			}
			else {
				userProfile.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all user profiles.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(UserProfileImpl.class.getName());
		}

		EntityCacheUtil.clearCache(UserProfileImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the user profile.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(UserProfile userProfile) {
		EntityCacheUtil.removeResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileImpl.class, userProfile.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(userProfile);
	}

	@Override
	public void clearCache(List<UserProfile> userProfiles) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (UserProfile userProfile : userProfiles) {
			EntityCacheUtil.removeResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
				UserProfileImpl.class, userProfile.getPrimaryKey());

			clearUniqueFindersCache(userProfile);
		}
	}

	protected void cacheUniqueFindersCache(UserProfile userProfile) {
		if (userProfile.isNew()) {
			Object[] args = new Object[] {
					userProfile.getUuid(), userProfile.getGroupId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
				userProfile);

			args = new Object[] { userProfile.getUserId() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_USERPROFILEID, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERPROFILEID, args,
				userProfile);
		}
		else {
			UserProfileModelImpl userProfileModelImpl = (UserProfileModelImpl)userProfile;

			if ((userProfileModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						userProfile.getUuid(), userProfile.getGroupId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
					userProfile);
			}

			if ((userProfileModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_USERPROFILEID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { userProfile.getUserId() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_USERPROFILEID,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
					args, userProfile);
			}
		}
	}

	protected void clearUniqueFindersCache(UserProfile userProfile) {
		UserProfileModelImpl userProfileModelImpl = (UserProfileModelImpl)userProfile;

		Object[] args = new Object[] {
				userProfile.getUuid(), userProfile.getGroupId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);

		if ((userProfileModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
			args = new Object[] {
					userProfileModelImpl.getOriginalUuid(),
					userProfileModelImpl.getOriginalGroupId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);
		}

		args = new Object[] { userProfile.getUserId() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERPROFILEID, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_USERPROFILEID, args);

		if ((userProfileModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_USERPROFILEID.getColumnBitmask()) != 0) {
			args = new Object[] { userProfileModelImpl.getOriginalUserId() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERPROFILEID,
				args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_USERPROFILEID,
				args);
		}
	}

	/**
	 * Creates a new user profile with the primary key. Does not add the user profile to the database.
	 *
	 * @param userProfileId the primary key for the new user profile
	 * @return the new user profile
	 */
	@Override
	public UserProfile create(long userProfileId) {
		UserProfile userProfile = new UserProfileImpl();

		userProfile.setNew(true);
		userProfile.setPrimaryKey(userProfileId);

		String uuid = PortalUUIDUtil.generate();

		userProfile.setUuid(uuid);

		return userProfile;
	}

	/**
	 * Removes the user profile with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param userProfileId the primary key of the user profile
	 * @return the user profile that was removed
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile remove(long userProfileId)
		throws NoSuchUserProfileException, SystemException {
		return remove((Serializable)userProfileId);
	}

	/**
	 * Removes the user profile with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the user profile
	 * @return the user profile that was removed
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile remove(Serializable primaryKey)
		throws NoSuchUserProfileException, SystemException {
		Session session = null;

		try {
			session = openSession();

			UserProfile userProfile = (UserProfile)session.get(UserProfileImpl.class,
					primaryKey);

			if (userProfile == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchUserProfileException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(userProfile);
		}
		catch (NoSuchUserProfileException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected UserProfile removeImpl(UserProfile userProfile)
		throws SystemException {
		userProfile = toUnwrappedModel(userProfile);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(userProfile)) {
				userProfile = (UserProfile)session.get(UserProfileImpl.class,
						userProfile.getPrimaryKeyObj());
			}

			if (userProfile != null) {
				session.delete(userProfile);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (userProfile != null) {
			clearCache(userProfile);
		}

		return userProfile;
	}

	@Override
	public UserProfile updateImpl(
		com.lepuserprofile.model.UserProfile userProfile)
		throws SystemException {
		userProfile = toUnwrappedModel(userProfile);

		boolean isNew = userProfile.isNew();

		UserProfileModelImpl userProfileModelImpl = (UserProfileModelImpl)userProfile;

		if (Validator.isNull(userProfile.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			userProfile.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (userProfile.isNew()) {
				session.save(userProfile);

				userProfile.setNew(false);
			}
			else {
				session.merge(userProfile);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !UserProfileModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((userProfileModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						userProfileModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { userProfileModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((userProfileModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						userProfileModelImpl.getOriginalUuid(),
						userProfileModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);

				args = new Object[] {
						userProfileModelImpl.getUuid(),
						userProfileModelImpl.getCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);
			}

			if ((userProfileModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERPROFILE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						userProfileModelImpl.getOriginalUserId(),
						userProfileModelImpl.getOriginalUserProfileStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERPROFILE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERPROFILE,
					args);

				args = new Object[] {
						userProfileModelImpl.getUserId(),
						userProfileModelImpl.getUserProfileStatus()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_USERPROFILE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_USERPROFILE,
					args);
			}
		}

		EntityCacheUtil.putResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
			UserProfileImpl.class, userProfile.getPrimaryKey(), userProfile);

		clearUniqueFindersCache(userProfile);
		cacheUniqueFindersCache(userProfile);

		return userProfile;
	}

	protected UserProfile toUnwrappedModel(UserProfile userProfile) {
		if (userProfile instanceof UserProfileImpl) {
			return userProfile;
		}

		UserProfileImpl userProfileImpl = new UserProfileImpl();

		userProfileImpl.setNew(userProfile.isNew());
		userProfileImpl.setPrimaryKey(userProfile.getPrimaryKey());

		userProfileImpl.setUuid(userProfile.getUuid());
		userProfileImpl.setUserProfileId(userProfile.getUserProfileId());
		userProfileImpl.setResourcePrimKey(userProfile.getResourcePrimKey());
		userProfileImpl.setFirstName(userProfile.getFirstName());
		userProfileImpl.setLastName(userProfile.getLastName());
		userProfileImpl.setJobTitle(userProfile.getJobTitle());
		userProfileImpl.setSite(userProfile.getSite());
		userProfileImpl.setBioData(userProfile.getBioData());
		userProfileImpl.setUserProfileStatus(userProfile.getUserProfileStatus());
		userProfileImpl.setStatusByUserId(userProfile.getStatusByUserId());
		userProfileImpl.setStatusDate(userProfile.getStatusDate());
		userProfileImpl.setGroupId(userProfile.getGroupId());
		userProfileImpl.setUserId(userProfile.getUserId());
		userProfileImpl.setUserName(userProfile.getUserName());
		userProfileImpl.setCompanyId(userProfile.getCompanyId());
		userProfileImpl.setCreateDate(userProfile.getCreateDate());
		userProfileImpl.setModifiedDate(userProfile.getModifiedDate());

		return userProfileImpl;
	}

	/**
	 * Returns the user profile with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the user profile
	 * @return the user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByPrimaryKey(Serializable primaryKey)
		throws NoSuchUserProfileException, SystemException {
		UserProfile userProfile = fetchByPrimaryKey(primaryKey);

		if (userProfile == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchUserProfileException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return userProfile;
	}

	/**
	 * Returns the user profile with the primary key or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	 *
	 * @param userProfileId the primary key of the user profile
	 * @return the user profile
	 * @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile findByPrimaryKey(long userProfileId)
		throws NoSuchUserProfileException, SystemException {
		return findByPrimaryKey((Serializable)userProfileId);
	}

	/**
	 * Returns the user profile with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the user profile
	 * @return the user profile, or <code>null</code> if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		UserProfile userProfile = (UserProfile)EntityCacheUtil.getResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
				UserProfileImpl.class, primaryKey);

		if (userProfile == _nullUserProfile) {
			return null;
		}

		if (userProfile == null) {
			Session session = null;

			try {
				session = openSession();

				userProfile = (UserProfile)session.get(UserProfileImpl.class,
						primaryKey);

				if (userProfile != null) {
					cacheResult(userProfile);
				}
				else {
					EntityCacheUtil.putResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
						UserProfileImpl.class, primaryKey, _nullUserProfile);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(UserProfileModelImpl.ENTITY_CACHE_ENABLED,
					UserProfileImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return userProfile;
	}

	/**
	 * Returns the user profile with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param userProfileId the primary key of the user profile
	 * @return the user profile, or <code>null</code> if a user profile with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public UserProfile fetchByPrimaryKey(long userProfileId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)userProfileId);
	}

	/**
	 * Returns all the user profiles.
	 *
	 * @return the user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the user profiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @return the range of user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the user profiles.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of user profiles
	 * @param end the upper bound of the range of user profiles (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<UserProfile> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<UserProfile> list = (List<UserProfile>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_USERPROFILE);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_USERPROFILE;

				if (pagination) {
					sql = sql.concat(UserProfileModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<UserProfile>(list);
				}
				else {
					list = (List<UserProfile>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the user profiles from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (UserProfile userProfile : findAll()) {
			remove(userProfile);
		}
	}

	/**
	 * Returns the number of user profiles.
	 *
	 * @return the number of user profiles
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_USERPROFILE);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the user profile persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.lepuserprofile.model.UserProfile")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<UserProfile>> listenersList = new ArrayList<ModelListener<UserProfile>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<UserProfile>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(UserProfileImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_USERPROFILE = "SELECT userProfile FROM UserProfile userProfile";
	private static final String _SQL_SELECT_USERPROFILE_WHERE = "SELECT userProfile FROM UserProfile userProfile WHERE ";
	private static final String _SQL_COUNT_USERPROFILE = "SELECT COUNT(userProfile) FROM UserProfile userProfile";
	private static final String _SQL_COUNT_USERPROFILE_WHERE = "SELECT COUNT(userProfile) FROM UserProfile userProfile WHERE ";
	private static final String _ORDER_BY_ENTITY_ALIAS = "userProfile.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No UserProfile exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No UserProfile exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(UserProfilePersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid"
			});
	private static UserProfile _nullUserProfile = new UserProfileImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<UserProfile> toCacheModel() {
				return _nullUserProfileCacheModel;
			}
		};

	private static CacheModel<UserProfile> _nullUserProfileCacheModel = new CacheModel<UserProfile>() {
			@Override
			public UserProfile toEntityModel() {
				return _nullUserProfile;
			}
		};
}