package com.lepuserprofile.handler;

import com.lepuserprofile.helper.LEPUserProfileHelper;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class LEPUserProfile extends MVCPortlet {
	private static final Log LOGGER = LogFactoryUtil.getLog(LEPUserProfile.class);
	


	public void editProfile(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException, PortalException, SystemException {
		
		LEPUserProfileHelper.addEditUserProfile(actionRequest, actionResponse);
	}
	
	@Override
	public void render(RenderRequest renderReq, RenderResponse renderRes)
			throws PortletException, IOException {
		
		LEPUserProfileHelper.userProfileRender(renderReq, renderRes);
		
		super.render(renderReq, renderRes);
	}
}
