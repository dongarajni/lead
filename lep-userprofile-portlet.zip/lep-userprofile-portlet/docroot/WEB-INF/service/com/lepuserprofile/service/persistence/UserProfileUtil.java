/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.lepuserprofile.service.persistence;

import com.lepuserprofile.model.UserProfile;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import java.util.List;

/**
 * The persistence utility for the user profile service. This utility wraps {@link UserProfilePersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author rajnikant.donga
 * @see UserProfilePersistence
 * @see UserProfilePersistenceImpl
 * @generated
 */
public class UserProfileUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(UserProfile userProfile) {
		getPersistence().clearCache(userProfile);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<UserProfile> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<UserProfile> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<UserProfile> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static UserProfile update(UserProfile userProfile)
		throws SystemException {
		return getPersistence().update(userProfile);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static UserProfile update(UserProfile userProfile,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(userProfile, serviceContext);
	}

	/**
	* Returns all the user profiles where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the user profiles where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the user profiles where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns the first user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last user profile in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the user profiles before and after the current user profile in the ordered set where uuid = &#63;.
	*
	* @param userProfileId the primary key of the current user profile
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile[] findByUuid_PrevAndNext(
		long userProfileId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_PrevAndNext(userProfileId, uuid,
			orderByComparator);
	}

	/**
	* Removes all the user profiles where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of user profiles where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the user profile where uuid = &#63; and groupId = &#63; or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the user profile where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the user profile where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the user profile where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the user profile that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of user profiles where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the user profiles where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the user profiles where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the user profiles where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns the first user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the user profiles before and after the current user profile in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param userProfileId the primary key of the current user profile
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile[] findByUuid_C_PrevAndNext(
		long userProfileId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(userProfileId, uuid, companyId,
			orderByComparator);
	}

	/**
	* Removes all the user profiles where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of user profiles where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Returns all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @return the matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByuserProfile(
		long userId, int userProfileStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserProfile(userId, userProfileStatus);
	}

	/**
	* Returns a range of all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByuserProfile(
		long userId, int userProfileStatus, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserProfile(userId, userProfileStatus, start, end);
	}

	/**
	* Returns an ordered range of all the user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findByuserProfile(
		long userId, int userProfileStatus, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserProfile(userId, userProfileStatus, start, end,
			orderByComparator);
	}

	/**
	* Returns the first user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByuserProfile_First(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserProfile_First(userId, userProfileStatus,
			orderByComparator);
	}

	/**
	* Returns the first user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByuserProfile_First(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserProfile_First(userId, userProfileStatus,
			orderByComparator);
	}

	/**
	* Returns the last user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByuserProfile_Last(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserProfile_Last(userId, userProfileStatus,
			orderByComparator);
	}

	/**
	* Returns the last user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByuserProfile_Last(
		long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserProfile_Last(userId, userProfileStatus,
			orderByComparator);
	}

	/**
	* Returns the user profiles before and after the current user profile in the ordered set where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userProfileId the primary key of the current user profile
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile[] findByuserProfile_PrevAndNext(
		long userProfileId, long userId, int userProfileStatus,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserProfile_PrevAndNext(userProfileId, userId,
			userProfileStatus, orderByComparator);
	}

	/**
	* Removes all the user profiles where userId = &#63; and userProfileStatus = &#63; from the database.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserProfile(long userId, int userProfileStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserProfile(userId, userProfileStatus);
	}

	/**
	* Returns the number of user profiles where userId = &#63; and userProfileStatus = &#63;.
	*
	* @param userId the user ID
	* @param userProfileStatus the user profile status
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserProfile(long userId, int userProfileStatus)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserProfile(userId, userProfileStatus);
	}

	/**
	* Returns the user profile where userId = &#63; or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	*
	* @param userId the user ID
	* @return the matching user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByuserProfileId(
		long userId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserProfileId(userId);
	}

	/**
	* Returns the user profile where userId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param userId the user ID
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByuserProfileId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByuserProfileId(userId);
	}

	/**
	* Returns the user profile where userId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param userId the user ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching user profile, or <code>null</code> if a matching user profile could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByuserProfileId(
		long userId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByuserProfileId(userId, retrieveFromCache);
	}

	/**
	* Removes the user profile where userId = &#63; from the database.
	*
	* @param userId the user ID
	* @return the user profile that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile removeByuserProfileId(
		long userId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().removeByuserProfileId(userId);
	}

	/**
	* Returns the number of user profiles where userId = &#63;.
	*
	* @param userId the user ID
	* @return the number of matching user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserProfileId(long userId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserProfileId(userId);
	}

	/**
	* Caches the user profile in the entity cache if it is enabled.
	*
	* @param userProfile the user profile
	*/
	public static void cacheResult(
		com.lepuserprofile.model.UserProfile userProfile) {
		getPersistence().cacheResult(userProfile);
	}

	/**
	* Caches the user profiles in the entity cache if it is enabled.
	*
	* @param userProfiles the user profiles
	*/
	public static void cacheResult(
		java.util.List<com.lepuserprofile.model.UserProfile> userProfiles) {
		getPersistence().cacheResult(userProfiles);
	}

	/**
	* Creates a new user profile with the primary key. Does not add the user profile to the database.
	*
	* @param userProfileId the primary key for the new user profile
	* @return the new user profile
	*/
	public static com.lepuserprofile.model.UserProfile create(
		long userProfileId) {
		return getPersistence().create(userProfileId);
	}

	/**
	* Removes the user profile with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userProfileId the primary key of the user profile
	* @return the user profile that was removed
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile remove(
		long userProfileId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().remove(userProfileId);
	}

	public static com.lepuserprofile.model.UserProfile updateImpl(
		com.lepuserprofile.model.UserProfile userProfile)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(userProfile);
	}

	/**
	* Returns the user profile with the primary key or throws a {@link com.lepuserprofile.NoSuchUserProfileException} if it could not be found.
	*
	* @param userProfileId the primary key of the user profile
	* @return the user profile
	* @throws com.lepuserprofile.NoSuchUserProfileException if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile findByPrimaryKey(
		long userProfileId)
		throws com.lepuserprofile.NoSuchUserProfileException,
			com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPrimaryKey(userProfileId);
	}

	/**
	* Returns the user profile with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param userProfileId the primary key of the user profile
	* @return the user profile, or <code>null</code> if a user profile with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.lepuserprofile.model.UserProfile fetchByPrimaryKey(
		long userProfileId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(userProfileId);
	}

	/**
	* Returns all the user profiles.
	*
	* @return the user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the user profiles.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @return the range of user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the user profiles.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.lepuserprofile.model.impl.UserProfileModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user profiles
	* @param end the upper bound of the range of user profiles (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.lepuserprofile.model.UserProfile> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the user profiles from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of user profiles.
	*
	* @return the number of user profiles
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static UserProfilePersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (UserProfilePersistence)PortletBeanLocatorUtil.locate(com.lepuserprofile.service.ClpSerializer.getServletContextName(),
					UserProfilePersistence.class.getName());

			ReferenceRegistry.registerReference(UserProfileUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(UserProfilePersistence persistence) {
	}

	private static UserProfilePersistence _persistence;
}