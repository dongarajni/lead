/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.lepuserprofile.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link UserProfile}.
 * </p>
 *
 * @author rajnikant.donga
 * @see UserProfile
 * @generated
 */
public class UserProfileWrapper implements UserProfile,
	ModelWrapper<UserProfile> {
	public UserProfileWrapper(UserProfile userProfile) {
		_userProfile = userProfile;
	}

	@Override
	public Class<?> getModelClass() {
		return UserProfile.class;
	}

	@Override
	public String getModelClassName() {
		return UserProfile.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("userProfileId", getUserProfileId());
		attributes.put("resourcePrimKey", getResourcePrimKey());
		attributes.put("firstName", getFirstName());
		attributes.put("lastName", getLastName());
		attributes.put("jobTitle", getJobTitle());
		attributes.put("site", getSite());
		attributes.put("bioData", getBioData());
		attributes.put("userProfileStatus", getUserProfileStatus());
		attributes.put("statusByUserId", getStatusByUserId());
		attributes.put("statusDate", getStatusDate());
		attributes.put("groupId", getGroupId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("companyId", getCompanyId());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long userProfileId = (Long)attributes.get("userProfileId");

		if (userProfileId != null) {
			setUserProfileId(userProfileId);
		}

		Long resourcePrimKey = (Long)attributes.get("resourcePrimKey");

		if (resourcePrimKey != null) {
			setResourcePrimKey(resourcePrimKey);
		}

		String firstName = (String)attributes.get("firstName");

		if (firstName != null) {
			setFirstName(firstName);
		}

		String lastName = (String)attributes.get("lastName");

		if (lastName != null) {
			setLastName(lastName);
		}

		String jobTitle = (String)attributes.get("jobTitle");

		if (jobTitle != null) {
			setJobTitle(jobTitle);
		}

		String site = (String)attributes.get("site");

		if (site != null) {
			setSite(site);
		}

		String bioData = (String)attributes.get("bioData");

		if (bioData != null) {
			setBioData(bioData);
		}

		Integer userProfileStatus = (Integer)attributes.get("userProfileStatus");

		if (userProfileStatus != null) {
			setUserProfileStatus(userProfileStatus);
		}

		Long statusByUserId = (Long)attributes.get("statusByUserId");

		if (statusByUserId != null) {
			setStatusByUserId(statusByUserId);
		}

		Date statusDate = (Date)attributes.get("statusDate");

		if (statusDate != null) {
			setStatusDate(statusDate);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	* Returns the primary key of this user profile.
	*
	* @return the primary key of this user profile
	*/
	@Override
	public long getPrimaryKey() {
		return _userProfile.getPrimaryKey();
	}

	/**
	* Sets the primary key of this user profile.
	*
	* @param primaryKey the primary key of this user profile
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_userProfile.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this user profile.
	*
	* @return the uuid of this user profile
	*/
	@Override
	public java.lang.String getUuid() {
		return _userProfile.getUuid();
	}

	/**
	* Sets the uuid of this user profile.
	*
	* @param uuid the uuid of this user profile
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_userProfile.setUuid(uuid);
	}

	/**
	* Returns the user profile ID of this user profile.
	*
	* @return the user profile ID of this user profile
	*/
	@Override
	public long getUserProfileId() {
		return _userProfile.getUserProfileId();
	}

	/**
	* Sets the user profile ID of this user profile.
	*
	* @param userProfileId the user profile ID of this user profile
	*/
	@Override
	public void setUserProfileId(long userProfileId) {
		_userProfile.setUserProfileId(userProfileId);
	}

	/**
	* Returns the resource prim key of this user profile.
	*
	* @return the resource prim key of this user profile
	*/
	@Override
	public long getResourcePrimKey() {
		return _userProfile.getResourcePrimKey();
	}

	/**
	* Sets the resource prim key of this user profile.
	*
	* @param resourcePrimKey the resource prim key of this user profile
	*/
	@Override
	public void setResourcePrimKey(long resourcePrimKey) {
		_userProfile.setResourcePrimKey(resourcePrimKey);
	}

	@Override
	public boolean isResourceMain() {
		return _userProfile.isResourceMain();
	}

	/**
	* Returns the first name of this user profile.
	*
	* @return the first name of this user profile
	*/
	@Override
	public java.lang.String getFirstName() {
		return _userProfile.getFirstName();
	}

	/**
	* Sets the first name of this user profile.
	*
	* @param firstName the first name of this user profile
	*/
	@Override
	public void setFirstName(java.lang.String firstName) {
		_userProfile.setFirstName(firstName);
	}

	/**
	* Returns the last name of this user profile.
	*
	* @return the last name of this user profile
	*/
	@Override
	public java.lang.String getLastName() {
		return _userProfile.getLastName();
	}

	/**
	* Sets the last name of this user profile.
	*
	* @param lastName the last name of this user profile
	*/
	@Override
	public void setLastName(java.lang.String lastName) {
		_userProfile.setLastName(lastName);
	}

	/**
	* Returns the job title of this user profile.
	*
	* @return the job title of this user profile
	*/
	@Override
	public java.lang.String getJobTitle() {
		return _userProfile.getJobTitle();
	}

	/**
	* Sets the job title of this user profile.
	*
	* @param jobTitle the job title of this user profile
	*/
	@Override
	public void setJobTitle(java.lang.String jobTitle) {
		_userProfile.setJobTitle(jobTitle);
	}

	/**
	* Returns the site of this user profile.
	*
	* @return the site of this user profile
	*/
	@Override
	public java.lang.String getSite() {
		return _userProfile.getSite();
	}

	/**
	* Sets the site of this user profile.
	*
	* @param site the site of this user profile
	*/
	@Override
	public void setSite(java.lang.String site) {
		_userProfile.setSite(site);
	}

	/**
	* Returns the bio data of this user profile.
	*
	* @return the bio data of this user profile
	*/
	@Override
	public java.lang.String getBioData() {
		return _userProfile.getBioData();
	}

	/**
	* Sets the bio data of this user profile.
	*
	* @param bioData the bio data of this user profile
	*/
	@Override
	public void setBioData(java.lang.String bioData) {
		_userProfile.setBioData(bioData);
	}

	/**
	* Returns the user profile status of this user profile.
	*
	* @return the user profile status of this user profile
	*/
	@Override
	public int getUserProfileStatus() {
		return _userProfile.getUserProfileStatus();
	}

	/**
	* Sets the user profile status of this user profile.
	*
	* @param userProfileStatus the user profile status of this user profile
	*/
	@Override
	public void setUserProfileStatus(int userProfileStatus) {
		_userProfile.setUserProfileStatus(userProfileStatus);
	}

	/**
	* Returns the status by user ID of this user profile.
	*
	* @return the status by user ID of this user profile
	*/
	@Override
	public long getStatusByUserId() {
		return _userProfile.getStatusByUserId();
	}

	/**
	* Sets the status by user ID of this user profile.
	*
	* @param statusByUserId the status by user ID of this user profile
	*/
	@Override
	public void setStatusByUserId(long statusByUserId) {
		_userProfile.setStatusByUserId(statusByUserId);
	}

	/**
	* Returns the status by user uuid of this user profile.
	*
	* @return the status by user uuid of this user profile
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getStatusByUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userProfile.getStatusByUserUuid();
	}

	/**
	* Sets the status by user uuid of this user profile.
	*
	* @param statusByUserUuid the status by user uuid of this user profile
	*/
	@Override
	public void setStatusByUserUuid(java.lang.String statusByUserUuid) {
		_userProfile.setStatusByUserUuid(statusByUserUuid);
	}

	/**
	* Returns the status date of this user profile.
	*
	* @return the status date of this user profile
	*/
	@Override
	public java.util.Date getStatusDate() {
		return _userProfile.getStatusDate();
	}

	/**
	* Sets the status date of this user profile.
	*
	* @param statusDate the status date of this user profile
	*/
	@Override
	public void setStatusDate(java.util.Date statusDate) {
		_userProfile.setStatusDate(statusDate);
	}

	/**
	* Returns the group ID of this user profile.
	*
	* @return the group ID of this user profile
	*/
	@Override
	public long getGroupId() {
		return _userProfile.getGroupId();
	}

	/**
	* Sets the group ID of this user profile.
	*
	* @param groupId the group ID of this user profile
	*/
	@Override
	public void setGroupId(long groupId) {
		_userProfile.setGroupId(groupId);
	}

	/**
	* Returns the user ID of this user profile.
	*
	* @return the user ID of this user profile
	*/
	@Override
	public long getUserId() {
		return _userProfile.getUserId();
	}

	/**
	* Sets the user ID of this user profile.
	*
	* @param userId the user ID of this user profile
	*/
	@Override
	public void setUserId(long userId) {
		_userProfile.setUserId(userId);
	}

	/**
	* Returns the user uuid of this user profile.
	*
	* @return the user uuid of this user profile
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userProfile.getUserUuid();
	}

	/**
	* Sets the user uuid of this user profile.
	*
	* @param userUuid the user uuid of this user profile
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_userProfile.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this user profile.
	*
	* @return the user name of this user profile
	*/
	@Override
	public java.lang.String getUserName() {
		return _userProfile.getUserName();
	}

	/**
	* Sets the user name of this user profile.
	*
	* @param userName the user name of this user profile
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_userProfile.setUserName(userName);
	}

	/**
	* Returns the company ID of this user profile.
	*
	* @return the company ID of this user profile
	*/
	@Override
	public long getCompanyId() {
		return _userProfile.getCompanyId();
	}

	/**
	* Sets the company ID of this user profile.
	*
	* @param companyId the company ID of this user profile
	*/
	@Override
	public void setCompanyId(long companyId) {
		_userProfile.setCompanyId(companyId);
	}

	/**
	* Returns the create date of this user profile.
	*
	* @return the create date of this user profile
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _userProfile.getCreateDate();
	}

	/**
	* Sets the create date of this user profile.
	*
	* @param createDate the create date of this user profile
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_userProfile.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this user profile.
	*
	* @return the modified date of this user profile
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _userProfile.getModifiedDate();
	}

	/**
	* Sets the modified date of this user profile.
	*
	* @param modifiedDate the modified date of this user profile
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_userProfile.setModifiedDate(modifiedDate);
	}

	@Override
	public boolean isNew() {
		return _userProfile.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_userProfile.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _userProfile.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_userProfile.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _userProfile.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _userProfile.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_userProfile.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _userProfile.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_userProfile.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_userProfile.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_userProfile.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new UserProfileWrapper((UserProfile)_userProfile.clone());
	}

	@Override
	public int compareTo(com.lepuserprofile.model.UserProfile userProfile) {
		return _userProfile.compareTo(userProfile);
	}

	@Override
	public int hashCode() {
		return _userProfile.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.lepuserprofile.model.UserProfile> toCacheModel() {
		return _userProfile.toCacheModel();
	}

	@Override
	public com.lepuserprofile.model.UserProfile toEscapedModel() {
		return new UserProfileWrapper(_userProfile.toEscapedModel());
	}

	@Override
	public com.lepuserprofile.model.UserProfile toUnescapedModel() {
		return new UserProfileWrapper(_userProfile.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _userProfile.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _userProfile.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_userProfile.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserProfileWrapper)) {
			return false;
		}

		UserProfileWrapper userProfileWrapper = (UserProfileWrapper)obj;

		if (Validator.equals(_userProfile, userProfileWrapper._userProfile)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _userProfile.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public UserProfile getWrappedUserProfile() {
		return _userProfile;
	}

	@Override
	public UserProfile getWrappedModel() {
		return _userProfile;
	}

	@Override
	public void resetOriginalValues() {
		_userProfile.resetOriginalValues();
	}

	private UserProfile _userProfile;
}