package com.lepuserprofile.handler;

import com.lepuserprofile.model.UserProfile;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.model.User;
import com.liferay.portlet.asset.model.BaseAssetRenderer;

import java.util.Locale;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

public class UserProfileAssetRenderer extends BaseAssetRenderer {

	private UserProfile _userProfile;
	
	public UserProfileAssetRenderer(UserProfile userProfile) {
		_userProfile = userProfile;
    }
	
	
	public String getClassName() {
		// TODO Auto-generated method stub
		return UserProfile.class.getName();
	}

	
	public long getClassPK() {
		// TODO Auto-generated method stub
		return _userProfile.getUserProfileId();
	}


	public long getGroupId() {
		// TODO Auto-generated method stub
		return _userProfile.getGroupId();
		
	}

	
	public String getSummary(Locale arg0) {
		// TODO Auto-generated method stub
		return _userProfile.getFirstName();
	}

	
	public String getTitle(Locale arg0) {
		// TODO Auto-generated method stub
		return "User Profile";
	}

	
	public long getUserId() {
		// TODO Auto-generated method stub
		return _userProfile.getUserId();
	}

	@Override
	public String getUserName() {
		// TODO Auto-generated method stub
		return _userProfile.getUserName();
	}

	
	public String getUuid() {
		// TODO Auto-generated method stub
		return _userProfile.getUuid();
	}

	
	public String render(RenderRequest request, RenderResponse response, String template)
			throws Exception {
		System.out.println("=====temaplate full content====");
		if (template.equals(TEMPLATE_FULL_CONTENT)) {
        	request.setAttribute("userProfileObject",_userProfile);
            return "/html/lepuserprofile/view_workflow.jsp";
        }
        else
        {
        	request.setAttribute("userProfile",_userProfile);
            return "/html/lepuserprofile/view_workflow.jsp";
        }
	}

}
