create index IX_8D6AFB96 on lep_UserProfile (userId);
create index IX_DD9C374A on lep_UserProfile (userId, userProfileStatus);
create index IX_7386AAD8 on lep_UserProfile (uuid_);
create index IX_8FE8A250 on lep_UserProfile (uuid_, companyId);
create unique index IX_A8D57CD2 on lep_UserProfile (uuid_, groupId);