package com.lepuserprofile.handler;

import com.lepuserprofile.model.UserProfile;
import com.lepuserprofile.service.UserProfileLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.workflow.BaseWorkflowHandler;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class UserProfileWorkflowHandler extends BaseWorkflowHandler {
	
	public static final String CLASS_NAME = UserProfile.class.getName();
	
	@Override
	public String getClassName() {
		// TODO Auto-generated method stub
		return CLASS_NAME;
	}

	@Override
	public String getType(Locale arg0) {
		// TODO Auto-generated method stub
		return "UserProfile";
	}

	@Override
	public Object updateStatus(int status, Map<String, Serializable> workflowContext)
			throws PortalException, SystemException {
		
		System.out.println("=== Calling Update Status Method ===");
		
		long userId = GetterUtil.getLong(workflowContext.get(WorkflowConstants.CONTEXT_USER_ID));
		long resourcePrimKey = GetterUtil.getLong(workflowContext.get(WorkflowConstants.CONTEXT_ENTRY_CLASS_PK));
		UserProfile userProfile = UserProfileLocalServiceUtil.getUserProfile(resourcePrimKey);
		userProfile.setUserProfileStatus(status);
		userProfile.setStatusByUserId(userId);
		userProfile.setStatusDate(new Date());
		
		userProfile = UserProfileLocalServiceUtil.updateUserProfile(userProfile);
		
		if (status == WorkflowConstants.STATUS_APPROVED) {
            AssetEntryLocalServiceUtil.updateVisible(UserProfile.class.getName(),
                    resourcePrimKey, true);
        } else {
        	AssetEntryLocalServiceUtil.updateVisible(UserProfile.class.getName(),
                    resourcePrimKey, false);
        }
		
		return userProfile;
	}

}
